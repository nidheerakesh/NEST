import { PomodoroTimer } from "../PomodoroTimer";

export default function PomodoroTimerExample() {
  return <PomodoroTimer workMinutes={25} breakMinutes={5} />;
}
